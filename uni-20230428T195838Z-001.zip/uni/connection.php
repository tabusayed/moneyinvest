<?php

$link=mysqli_connect("localhost","root","","blog");
if(!$link){
    die('connection Failed'.mysqli_connect_error());
}




?>
